# NeuroPick (Advanced) — Python / FastAPI Monorepo (Local Dev Scaffold)

This repository is a starter scaffold for the Advanced NeuroPick system (AWS-ready). It provides minimal FastAPI microservices and a docker-compose local dev environment so you can iterate quickly.

Services included:
- auth-service — user registration / login (skeleton)
- products-service — product CRUD endpoints (skeleton)
- reviews-service — review CRUD and moderation hooks (skeleton)
- ingestion-service — connectors & ingestion triggers (skeleton)
- ml-service — inference endpoints for sentiment/aspect/summarization (skeleton)

Dev infra (docker-compose):
- Postgres (for relational data)
- Redis (for caching / pubsub)

Getting started (local)
1. Copy `.env.example` to `.env` and modify values if necessary.
2. From repo root:
   docker-compose build
   docker-compose up
3. Open service endpoints:
   - Auth: http://localhost:8001/health
   - Products: http://localhost:8002/health
   - Reviews: http://localhost:8003/health
   - Ingestion: http://localhost:8004/health
   - ML: http://localhost:8005/health

What’s next
- I can implement DB connectivity + Alembic migrations and JWT auth for the auth-service.
- Or I can scaffold Terraform for the AWS infra (EKS + RDS + S3 + ECR + ElastiCache).
- Or add ML prototypes and a SageMaker integration.

Tell me which next step you prefer and I’ll implement it.